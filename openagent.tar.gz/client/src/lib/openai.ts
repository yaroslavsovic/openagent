import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateAvatar(prompt: string): Promise<string> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `Professional avatar image: ${prompt}. The image should be a high-quality professional headshot style avatar, suitable for profile pictures, with clean background.`,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    if (!response.data?.[0]?.url) {
      throw new Error("No image URL in response");
    }

    return response.data[0].url;
  } catch (error) {
    console.error("Failed to generate avatar:", error);
    throw error;
  }
}
