import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  voice: text("voice").notNull().default("alloy"),
  model: text("model").notNull().default("gpt-4"),
  temperature: integer("temperature").notNull().default(70),
  token_limit: integer("token_limit").notNull().default(2048),
  language: text("language").notNull().default("English"),
  first_message: text("first_message").notNull(),
  system_prompt: text("system_prompt").notNull(),
  tools: text("tools").array().notNull().default(["chat"]),
  secrets: text("secrets").notNull().default("{}"),
  avatar_url: text("avatar_url"),
  avatar_prompt: text("avatar_prompt"),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  status: text("status").notNull().default("active"),
  created_at: text("created_at").notNull().default("now()"),
});

export const insertAgentSchema = createInsertSchema(agents);
export const selectAgentSchema = createSelectSchema(agents);
export type InsertAgent = typeof agents.$inferInsert;
export type SelectAgent = typeof agents.$inferSelect;
