import { Router } from 'express';
import { db } from '@db';
import { agents } from '@db/schema';

const router = Router();

router.get('/api/agents', async (req, res) => {
  try {
    const allAgents = await db.select().from(agents);
    res.json(allAgents);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/api/agents', async (req, res) => {
  try {
    const [agent] = await db.insert(agents).values(req.body).returning();
    res.json(agent);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
